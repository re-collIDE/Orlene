TYPE=VIEW
query=select `p`.`id` AS `product_id`,`p`.`name` AS `product_name`,`cat`.`name` AS `category`,`sub`.`name` AS `subcategory`,`p`.`daily_rate` AS `daily_rate`,`p`.`stock_qty` AS `stock_qty`,`p`.`rental_count` AS `rental_count`,`p`.`maintenance_threshold` AS `maintenance_threshold`,`p`.`status` AS `status`,count(`r`.`id`) AS `total_rentals`,sum(case when `r`.`status` = \'ACTIVE\' then 1 else 0 end) AS `active_rentals`,sum(case when `r`.`status` = \'COMPLETED\' then 1 else 0 end) AS `completed_rentals`,coalesce(sum(`r`.`total_fee`),0) AS `total_revenue` from (((`orlene_db`.`products` `p` join `orlene_db`.`subcategories` `sub` on(`p`.`subcategory_id` = `sub`.`id`)) join `orlene_db`.`categories` `cat` on(`sub`.`category_id` = `cat`.`id`)) left join `orlene_db`.`rentals` `r` on(`r`.`product_id` = `p`.`id`)) group by `p`.`id`
md5=cd7184855f0317ad7936fc73f9938bcb
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=0001776493821167623
create-version=2
source=SELECT\n  p.id                          AS product_id,\n  p.name                        AS product_name,\n  cat.name                      AS category,\n  sub.name                      AS subcategory,\n  p.daily_rate,\n  p.stock_qty,\n  p.rental_count,\n  p.maintenance_threshold,\n  p.status,\n  COUNT(r.id)                   AS total_rentals,\n  SUM(CASE WHEN r.status = \'ACTIVE\'     THEN 1 ELSE 0 END) AS active_rentals,\n  SUM(CASE WHEN r.status = \'COMPLETED\'  THEN 1 ELSE 0 END) AS completed_rentals,\n  COALESCE(SUM(r.total_fee), 0) AS total_revenue\nFROM   products p\nJOIN   subcategories sub ON p.subcategory_id = sub.id\nJOIN   categories cat    ON sub.category_id  = cat.id\nLEFT JOIN rentals r      ON r.product_id = p.id\nGROUP BY p.id
client_cs_name=cp850
connection_cl_name=cp850_general_ci
view_body_utf8=select `p`.`id` AS `product_id`,`p`.`name` AS `product_name`,`cat`.`name` AS `category`,`sub`.`name` AS `subcategory`,`p`.`daily_rate` AS `daily_rate`,`p`.`stock_qty` AS `stock_qty`,`p`.`rental_count` AS `rental_count`,`p`.`maintenance_threshold` AS `maintenance_threshold`,`p`.`status` AS `status`,count(`r`.`id`) AS `total_rentals`,sum(case when `r`.`status` = \'ACTIVE\' then 1 else 0 end) AS `active_rentals`,sum(case when `r`.`status` = \'COMPLETED\' then 1 else 0 end) AS `completed_rentals`,coalesce(sum(`r`.`total_fee`),0) AS `total_revenue` from (((`orlene_db`.`products` `p` join `orlene_db`.`subcategories` `sub` on(`p`.`subcategory_id` = `sub`.`id`)) join `orlene_db`.`categories` `cat` on(`sub`.`category_id` = `cat`.`id`)) left join `orlene_db`.`rentals` `r` on(`r`.`product_id` = `p`.`id`)) group by `p`.`id`
mariadb-version=100432
