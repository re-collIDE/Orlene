TYPE=VIEW
query=select (select count(0) from `orlene_db`.`rentals` where `orlene_db`.`rentals`.`status` = \'PENDING\') AS `pending_approvals`,(select count(0) from `orlene_db`.`rentals` where `orlene_db`.`rentals`.`status` in (\'ACTIVE\',\'OVERDUE\')) AS `active_rentals`,(select count(0) from `orlene_db`.`sos_alerts` where `orlene_db`.`sos_alerts`.`status` = \'OPEN\') AS `open_sos`,(select count(0) from `orlene_db`.`maintenance_log` where `orlene_db`.`maintenance_log`.`resolved_at` is null) AS `in_maintenance`,(select count(0) from `orlene_db`.`rentals` where `orlene_db`.`rentals`.`status` = \'RETURNED\') AS `pending_inspection`,(select coalesce(sum(`orlene_db`.`rentals`.`total_fee`),0) from `orlene_db`.`rentals` where `orlene_db`.`rentals`.`status` = \'COMPLETED\') AS `total_revenue`
md5=b85eb655aa4d7bb118388691b0180a2e
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=0001776493821402807
create-version=2
source=SELECT\n  (SELECT COUNT(*) FROM rentals WHERE status = \'PENDING\')                    AS pending_approvals,\n  (SELECT COUNT(*) FROM rentals WHERE status IN (\'ACTIVE\',\'OVERDUE\'))         AS active_rentals,\n  (SELECT COUNT(*) FROM sos_alerts WHERE status = \'OPEN\')                     AS open_sos,\n  (SELECT COUNT(*) FROM maintenance_log WHERE resolved_at IS NULL)            AS in_maintenance,\n  (SELECT COUNT(*) FROM rentals WHERE status = \'RETURNED\')                    AS pending_inspection,\n  (SELECT COALESCE(SUM(total_fee),0) FROM rentals WHERE status=\'COMPLETED\')   AS total_revenue
client_cs_name=cp850
connection_cl_name=cp850_general_ci
view_body_utf8=select (select count(0) from `orlene_db`.`rentals` where `orlene_db`.`rentals`.`status` = \'PENDING\') AS `pending_approvals`,(select count(0) from `orlene_db`.`rentals` where `orlene_db`.`rentals`.`status` in (\'ACTIVE\',\'OVERDUE\')) AS `active_rentals`,(select count(0) from `orlene_db`.`sos_alerts` where `orlene_db`.`sos_alerts`.`status` = \'OPEN\') AS `open_sos`,(select count(0) from `orlene_db`.`maintenance_log` where `orlene_db`.`maintenance_log`.`resolved_at` is null) AS `in_maintenance`,(select count(0) from `orlene_db`.`rentals` where `orlene_db`.`rentals`.`status` = \'RETURNED\') AS `pending_inspection`,(select coalesce(sum(`orlene_db`.`rentals`.`total_fee`),0) from `orlene_db`.`rentals` where `orlene_db`.`rentals`.`status` = \'COMPLETED\') AS `total_revenue`
mariadb-version=100432
