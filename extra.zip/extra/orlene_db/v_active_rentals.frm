TYPE=VIEW
query=select `r`.`id` AS `rental_id`,`u`.`id` AS `user_id`,`u`.`name` AS `user_name`,`u`.`email` AS `email`,`u`.`phone` AS `phone`,`p`.`id` AS `product_id`,`p`.`name` AS `product_name`,`cat`.`name` AS `category`,`sub`.`name` AS `subcategory`,`r`.`start_date` AS `start_date`,`r`.`end_date` AS `end_date`,`r`.`days` AS `days`,`r`.`total_fee` AS `total_fee`,`r`.`status` AS `status`,`r`.`use_area` AS `use_area`,`r`.`use_city` AS `use_city`,`r`.`use_landmark` AS `use_landmark`,`r`.`use_lat` AS `use_lat`,`r`.`use_lng` AS `use_lng`,`r`.`pickup_at` AS `pickup_at`,to_days(curdate()) - to_days(`r`.`end_date`) AS `days_overdue` from ((((`orlene_db`.`rentals` `r` join `orlene_db`.`users` `u` on(`r`.`user_id` = `u`.`id`)) join `orlene_db`.`products` `p` on(`r`.`product_id` = `p`.`id`)) join `orlene_db`.`subcategories` `sub` on(`p`.`subcategory_id` = `sub`.`id`)) join `orlene_db`.`categories` `cat` on(`sub`.`category_id` = `cat`.`id`)) where `r`.`status` in (\'ACTIVE\',\'OVERDUE\')
md5=dc8a20fbd88c6462659fd14568531eca
updatable=1
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=0001776493821111418
create-version=2
source=SELECT\n  r.id          AS rental_id,\n  u.id          AS user_id,\n  u.name        AS user_name,\n  u.email,\n  u.phone,\n  p.id          AS product_id,\n  p.name        AS product_name,\n  cat.name      AS category,\n  sub.name      AS subcategory,\n  r.start_date,\n  r.end_date,\n  r.days,\n  r.total_fee,\n  r.status,\n  r.use_area,\n  r.use_city,\n  r.use_landmark,\n  r.use_lat,\n  r.use_lng,\n  r.pickup_at,\n  DATEDIFF(CURDATE(), r.end_date) AS days_overdue\nFROM   rentals r\nJOIN   users u          ON r.user_id      = u.id\nJOIN   products p       ON r.product_id   = p.id\nJOIN   subcategories sub ON p.subcategory_id = sub.id\nJOIN   categories cat   ON sub.category_id  = cat.id\nWHERE  r.status IN (\'ACTIVE\', \'OVERDUE\')
client_cs_name=cp850
connection_cl_name=cp850_general_ci
view_body_utf8=select `r`.`id` AS `rental_id`,`u`.`id` AS `user_id`,`u`.`name` AS `user_name`,`u`.`email` AS `email`,`u`.`phone` AS `phone`,`p`.`id` AS `product_id`,`p`.`name` AS `product_name`,`cat`.`name` AS `category`,`sub`.`name` AS `subcategory`,`r`.`start_date` AS `start_date`,`r`.`end_date` AS `end_date`,`r`.`days` AS `days`,`r`.`total_fee` AS `total_fee`,`r`.`status` AS `status`,`r`.`use_area` AS `use_area`,`r`.`use_city` AS `use_city`,`r`.`use_landmark` AS `use_landmark`,`r`.`use_lat` AS `use_lat`,`r`.`use_lng` AS `use_lng`,`r`.`pickup_at` AS `pickup_at`,to_days(curdate()) - to_days(`r`.`end_date`) AS `days_overdue` from ((((`orlene_db`.`rentals` `r` join `orlene_db`.`users` `u` on(`r`.`user_id` = `u`.`id`)) join `orlene_db`.`products` `p` on(`r`.`product_id` = `p`.`id`)) join `orlene_db`.`subcategories` `sub` on(`p`.`subcategory_id` = `sub`.`id`)) join `orlene_db`.`categories` `cat` on(`sub`.`category_id` = `cat`.`id`)) where `r`.`status` in (\'ACTIVE\',\'OVERDUE\')
mariadb-version=100432
