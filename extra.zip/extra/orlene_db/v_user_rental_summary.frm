TYPE=VIEW
query=select `u`.`id` AS `id`,`u`.`name` AS `name`,`u`.`email` AS `email`,`u`.`phone` AS `phone`,`u`.`created_at` AS `member_since`,count(`r`.`id`) AS `total_rentals`,sum(case when `r`.`status` = \'COMPLETED\' then 1 else 0 end) AS `completed`,sum(case when `r`.`status` in (\'ACTIVE\',\'OVERDUE\') then 1 else 0 end) AS `active`,sum(case when `r`.`status` = \'OVERDUE\' then 1 else 0 end) AS `overdue_count`,coalesce(sum(`r`.`total_fee`),0) AS `total_spent` from (`orlene_db`.`users` `u` left join `orlene_db`.`rentals` `r` on(`r`.`user_id` = `u`.`id`)) where `u`.`role` = \'user\' group by `u`.`id`
md5=564be7db06e15e2ec6bc779f2c00c7fb
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=0001776493821226520
create-version=2
source=SELECT\n  u.id,\n  u.name,\n  u.email,\n  u.phone,\n  u.created_at                  AS member_since,\n  COUNT(r.id)                   AS total_rentals,\n  SUM(CASE WHEN r.status = \'COMPLETED\'  THEN 1 ELSE 0 END) AS completed,\n  SUM(CASE WHEN r.status IN (\'ACTIVE\',\'OVERDUE\') THEN 1 ELSE 0 END) AS active,\n  SUM(CASE WHEN r.status = \'OVERDUE\'    THEN 1 ELSE 0 END) AS overdue_count,\n  COALESCE(SUM(r.total_fee), 0) AS total_spent\nFROM   users u\nLEFT JOIN rentals r ON r.user_id = u.id\nWHERE  u.role = \'user\'\nGROUP BY u.id
client_cs_name=cp850
connection_cl_name=cp850_general_ci
view_body_utf8=select `u`.`id` AS `id`,`u`.`name` AS `name`,`u`.`email` AS `email`,`u`.`phone` AS `phone`,`u`.`created_at` AS `member_since`,count(`r`.`id`) AS `total_rentals`,sum(case when `r`.`status` = \'COMPLETED\' then 1 else 0 end) AS `completed`,sum(case when `r`.`status` in (\'ACTIVE\',\'OVERDUE\') then 1 else 0 end) AS `active`,sum(case when `r`.`status` = \'OVERDUE\' then 1 else 0 end) AS `overdue_count`,coalesce(sum(`r`.`total_fee`),0) AS `total_spent` from (`orlene_db`.`users` `u` left join `orlene_db`.`rentals` `r` on(`r`.`user_id` = `u`.`id`)) where `u`.`role` = \'user\' group by `u`.`id`
mariadb-version=100432
