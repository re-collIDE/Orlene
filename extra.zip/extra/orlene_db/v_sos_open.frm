TYPE=VIEW
query=select `sa`.`id` AS `alert_id`,`sa`.`trigger_type` AS `trigger_type`,`sa`.`message` AS `message`,`sa`.`created_at` AS `alert_time`,`sa`.`status` AS `alert_status`,`u`.`name` AS `user_name`,`u`.`phone` AS `user_phone`,`p`.`name` AS `product_name`,`r`.`id` AS `rental_id`,`r`.`end_date` AS `end_date`,`r`.`use_area` AS `use_area`,`r`.`use_city` AS `use_city`,`r`.`use_lat` AS `use_lat`,`r`.`use_lng` AS `use_lng`,timestampdiff(HOUR,`sa`.`created_at`,current_timestamp()) AS `hours_since_alert` from (((`orlene_db`.`sos_alerts` `sa` join `orlene_db`.`rentals` `r` on(`sa`.`rental_id` = `r`.`id`)) join `orlene_db`.`users` `u` on(`sa`.`user_id` = `u`.`id`)) join `orlene_db`.`products` `p` on(`r`.`product_id` = `p`.`id`)) where `sa`.`status` = \'OPEN\' order by `sa`.`created_at` desc
md5=88c0ee3dc952a9f24f507db15389ddb6
updatable=1
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=0001776493821288568
create-version=2
source=SELECT\n  sa.id          AS alert_id,\n  sa.trigger_type,\n  sa.message,\n  sa.created_at  AS alert_time,\n  sa.status      AS alert_status,\n  u.name         AS user_name,\n  u.phone        AS user_phone,\n  p.name         AS product_name,\n  r.id           AS rental_id,\n  r.end_date,\n  r.use_area,\n  r.use_city,\n  r.use_lat,\n  r.use_lng,\n  TIMESTAMPDIFF(HOUR, sa.created_at, NOW()) AS hours_since_alert\nFROM   sos_alerts sa\nJOIN   rentals r  ON sa.rental_id  = r.id\nJOIN   users u    ON sa.user_id    = u.id\nJOIN   products p ON r.product_id  = p.id\nWHERE  sa.status = \'OPEN\'\nORDER BY sa.created_at DESC
client_cs_name=cp850
connection_cl_name=cp850_general_ci
view_body_utf8=select `sa`.`id` AS `alert_id`,`sa`.`trigger_type` AS `trigger_type`,`sa`.`message` AS `message`,`sa`.`created_at` AS `alert_time`,`sa`.`status` AS `alert_status`,`u`.`name` AS `user_name`,`u`.`phone` AS `user_phone`,`p`.`name` AS `product_name`,`r`.`id` AS `rental_id`,`r`.`end_date` AS `end_date`,`r`.`use_area` AS `use_area`,`r`.`use_city` AS `use_city`,`r`.`use_lat` AS `use_lat`,`r`.`use_lng` AS `use_lng`,timestampdiff(HOUR,`sa`.`created_at`,current_timestamp()) AS `hours_since_alert` from (((`orlene_db`.`sos_alerts` `sa` join `orlene_db`.`rentals` `r` on(`sa`.`rental_id` = `r`.`id`)) join `orlene_db`.`users` `u` on(`sa`.`user_id` = `u`.`id`)) join `orlene_db`.`products` `p` on(`r`.`product_id` = `p`.`id`)) where `sa`.`status` = \'OPEN\' order by `sa`.`created_at` desc
mariadb-version=100432
